$(document).ready(function () {

        $(document).on('click', '#calculateButton', function () {
            var startDateString = $('#dataInicio').val();
            var endDateString = $('#dataFim').val();

            if (!startDateString || !endDateString) {
                alert('Por favor, selecione a data de in�cio e a data de fim.');
                return;
            }

            var startDate = new Date(startDateString);
            var endDate = new Date(endDateString);
            var currentDate = new Date();
            currentDate.setHours(0, 0, 0, 0);


            if (endDate <= startDate) {
                alert('A data de fim deve ser posterior � data de in�cio.');
                return;
            }

            if (startDate < currentDate) {
                alert('A data de in�cio tem de ser igual ou posterior � data atual.');
                return;
            }

            var timeDiff = Math.abs(endDate.getTime() - startDate.getTime());
            var diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24));
            var insuranceCost = diffDays * 2.5;
            $('#insuranceCost').text('Custo do seguro: ' + insuranceCost + '\u20AC');
            $('#insuranceCost').show();
            $('#additionalButtons').show();
        });
        
        $(document).on('click', '#additionalButton', function () {
            var confirmation = window.confirm("Tem certeza de que deseja criar este seguro para si?");
            if (confirmation) {
                var startDateString = $('#dataInicio').val();
                var endDateString = $('#dataFim').val();
                var startDate = new Date(startDateString);
                var endDate = new Date(endDateString);
                var itype= $('#tipo').val();
                var paymethod = $('#metodoPagamento').val();
                var freq = $('#periodicidadePagamento').val();
                var cost = parseFloat($('#insuranceCost').text().replace('Custo do seguro: ', '').replace('\u20AC', ''));

                var requestData = {
                    Type: itype,
                    InsuranceHolder: user.Id,
                    PaymentMethod: paymethod,
                    Frequency: freq,
                    StartDate: startDate,
                    EndDate: endDate,
                    Cost: cost,
                    Status: false
                };

                $.ajax({
                    type: "POST",
                    url: `/api/Customer/AddInsurance`,
                    contentType: "application/json",
                    data: JSON.stringify(requestData),
                    success: function (data) {
                        console.log('Selected Insurance:', data);
                    },
                    error: function (xhr, status, error) {
                        console.error('Error fetching insurance data:', error);
                    }
                });
            } else {
            }
        });
    });