$(document).ready(function () {

    const insuranceData = insuranceDataJson.reverse();
    console.log("insuranceDataJson:", insuranceDataJson);

    function generateInsuranceCard(insurance) {
        const statusTextColor = insurance.status ? "#014751" : "red";
        const statusTextContent = insurance.status ? "Activo" : "Aguarda pagamento";
        return `
        <div class="col" style="margin: 10px;">
            <div class="card rounded-0" style="width: 100%;height: 240px;">
                <div class="card-header rounded-0" style="background-color: #014751; color: white;">
                    <div class="row align-items-center">
                        <div class="col">
                            <span>${insurance.type}<br />Ap\u00F3lice n\u00BA ${insurance.id}</span>
                        </div>
                        <div class="col d-flex justify-content-end">
                            <img src="/assets/SELECTORS/ic_auto_selector.png">
                        </div>
                    </div>
                </div>
                <div class="card-body" style="background-color: lightgrey;height: 125px; overflow: hidden;s">
                    <p class="card-text" style="font-size: 12px;">Pr\u00E9mio total ${insurance.frequency}</p>
                    <p style="color:#014751"><b>${insurance.cost}\u20AC</b></p>
                    <p style="font-size: 12px;">Estado</p>
                    <p style="color:${statusTextColor};"><b>${statusTextContent}</b></p>
                </div>
            </div>
        </div>
    `;
    }

updateCarousel(insuranceData);

function generateInsuranceCards(insuranceData) {
    let cardsHtml = "";
    insuranceData.forEach(insurance => {
        cardsHtml += generateInsuranceCard(insurance);
    });
    return cardsHtml;
}

function updateCarousel(insuranceData) {
    const carouselContainer = $('.slick-carousel');

    if (carouselContainer.hasClass('slick-initialized')) {
        carouselContainer.slick('unslick');
    }

    const cardsHtml = generateInsuranceCards(insuranceData);
    carouselContainer.html(cardsHtml);

    const slidesToScroll = Math.ceil(insuranceData.length / 3) + 1;

    carouselContainer.slick({
        slidesToShow: 3,
        slidesToScroll: slidesToScroll,
        arrows: false,
        Infinite: true,
    });

    $("#left-arrow").click(function () {
        carouselContainer.slick('slickPrev');
    });

    $("#right-arrow").click(function () {
        carouselContainer.slick('slickNext');
    });
}
    });