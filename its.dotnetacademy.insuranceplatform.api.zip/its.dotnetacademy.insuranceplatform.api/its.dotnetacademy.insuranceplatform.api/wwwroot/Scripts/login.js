// Form submission handler
$(document).ready(function () {
    $("#loginForm").submit(function (event) {
        event.preventDefault();

        console.log("Login button clicked");


        var username = $("#username").val();
        var password = $("#password").val();


        $.ajax({
            url: "/login",
            type: "POST",
            data: JSON.stringify({ username: username, password: password }),
            contentType: "application/json",
            dataType: "json",
            success: function (data) {
                if (data.isLoggedIn) {
                    console.log("Login successful");
                    var token = data.token;
                    encodeduser = encodeURIComponent(username);
                    document.cookie = `access_token=${encodeURIComponent(token)}; path=/; SameSite=Lax`;
                    window.location.href = "api/Customer/Dashboard?email=" + encodeduser;
                } else {
                    console.log("Login failed");
                    console.log(data.error);
                    alert("Invalid username or password. Please try again.");
                }
            },
            error: function (error) {
                console.log("3");
                console.error("Error:", error);
            }
        });
    });
});

