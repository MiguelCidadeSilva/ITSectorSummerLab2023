function validateAndSubmit(event) {
    event.preventDefault();

    const email = document.getElementById("email").value;
    const title = document.getElementById("title").value;
    const name = document.getElementById("name").value;
    const clientType = document.getElementById("clienttype").value;
    const nif = document.getElementById("nif").value;
    const documentType = document.getElementById("tipodocumento").value;
    const street = document.getElementById("rua").value;
    const neighbourhood = document.getElementById("bairro").value;
    const city = document.getElementById("cidade").value;
    const mobileNumber = document.getElementById("mobilenumber").value;
    const documentNumber = document.getElementById("nrdocumento").value;
    const municipality = document.getElementById("municipio").value;
    const province = document.getElementById("province").value;
    const phoneNumber = document.getElementById("phonenumber").value;
    const picture = null;
    const password = document.getElementById("password").value;
    const birthdate = new Date(document.getElementById("data").value);
    const currentDate = new Date();
    const age = currentDate.getFullYear() - birthdate.getFullYear();

    if (!email || !name || !nif || !password || !birthdate) {
        alert("Please fill in all required fields.");
        return;
    }

    if (isNaN(nif)) {
        alert("NIF must be a valid number.");
        return;
    }

    if (age < 18) {
        alert("You must be 18 years or older to create an account.");
        return;
    }



    const customerData = {
        NIF: parseInt(nif),
        Title: title,
        DocumentType: documentType,
        Street: street,
        Neighbourhood: neighbourhood,
        City: city,
        MobileNumber: mobileNumber,
        Email: email,
        ClientType: clientType,
        Name: name,
        DocumentNumber: documentNumber,
        Municipality: municipality,
        Province: province,
        PhoneNumber: phoneNumber,
        Picture: picture,
        Password: password,
        Birthdate: birthdate
    };

    const registerUrl = "api/Home/RegisterUser";

    $.ajax({
        type: "POST",
        url: registerUrl,
        contentType: "application/json",
        data: JSON.stringify(customerData),
        success: function (data) {
            console.log(data);
            alert("User created. Redirecting to the homepage...");
            window.location.href = "/";
        },
        error: function (error) {

            alert("Error");
        }
    });
}

document.getElementById("registerForm").onsubmit = validateAndSubmit;
