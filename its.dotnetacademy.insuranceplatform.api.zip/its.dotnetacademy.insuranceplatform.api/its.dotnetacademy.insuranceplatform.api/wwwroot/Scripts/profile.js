function displayProfilePicture(event) {
    var fileInput = event.target;
    if (fileInput.files && fileInput.files[0]) {
        var reader = new FileReader();
        reader.onload = function (e) {
            var profilePicture = document.getElementById("profilePicture");
            profilePicture.src = e.target.result;
        };
        reader.readAsDataURL(fileInput.files[0]);
    }
}


function updateProfilePicture(email) {
    var formData = new FormData();
    var fileInput = document.querySelector('input[type="file"]');
    console.log(email)
    formData.append("email", email);
    formData.append("formFile", fileInput.files[0]);

    $.ajax({
        type: "POST",
        url: "/api/Customer/UpdatePicture",
        data: formData,
        processData: false,
        contentType: false,
        success: function (data) {
            console.log(data);
            alert("Profile picture updated successfully.");
            location.reload();
        },
        error: function (error) {
            console.error(error);
            alert("Failed to update profile picture.");
        }
    });
}