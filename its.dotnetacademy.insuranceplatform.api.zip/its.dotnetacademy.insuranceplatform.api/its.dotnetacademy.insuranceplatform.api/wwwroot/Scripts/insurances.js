$(document).ready(function () {

    
function generateInsuranceCard(insurance) {
    const statusTextColor = insurance.status ? "#014751" : "red";
    const statusTextContent = insurance.status ? "Activo" : "Aguarda pagamento";
    return `
        <div class="col" style="margin: 10px;">
            <div class="card rounded-0" style="width: 100%;height: 240px;"onclick="selectCard(this)">
                <div class="card-header rounded-0" style="background-color: #014751; color: white;">
                    <div class="row align-items-center">
                        <div class="col">
                            <span>${insurance.type}<br />Ap\u00F3lice n\u00BA ${insurance.id}</span>
                        </div>
                        <div class="col d-flex justify-content-end">
                            <img src="/assets/SELECTORS/ic_auto_selector.png">
                        </div>
                    </div>
                </div>
                <div class="card-body" style="background-color: lightgrey;height: 125px; overflow: hidden;s">
                    <p class="card-text" style="font-size: 12px;">Pr\u00E9mio total ${insurance.frequency}</p>
                    <p style="color:#014751"><b>${insurance.cost}\u20AC</b></p>
                    <p style="font-size: 12px;">Estado</p>
                    <p style="color:${statusTextColor};"><b>${statusTextContent}</b></p>
                </div>
            </div>
        </div>
    `;
}

updateCarousel(insuranceData);

function generateInsuranceCards(insuranceData) {
    let cardsHtml = "";
    insuranceData.forEach(insurance => {
        cardsHtml += generateInsuranceCard(insurance);
    });
    return cardsHtml;
}

function updateCarousel(insuranceData) {
    const carouselContainer = $('.slick-carousel');

    if (carouselContainer.hasClass('slick-initialized')) {
        carouselContainer.slick('unslick');
    }

    const cardsHtml = generateInsuranceCards(insuranceData);
    carouselContainer.html(cardsHtml);

    const slidesToScroll = Math.ceil(insuranceData.length / 3) + 1;

    carouselContainer.slick({
        slidesToShow: 3,
        slidesToScroll: slidesToScroll,
        arrows: false,
        Infinite: true,
    });

    $("#left-arrow").click(function () {
        carouselContainer.slick('slickPrev');
    });

    $("#right-arrow").click(function () {
        carouselContainer.slick('slickNext');
    });
}
    });


function selectCard(card) {
    const cards = document.getElementsByClassName('card');
    for (let i = 0; i < cards.length; i++) {
        console.log(cards[i])
        cards[i].classList.remove('selected');
    }

    card.classList.add('selected');

    const insuranceId = parseInt(card.querySelector('span').innerText.match(/\d+/)[0]);

    $.ajax({
        type: "GET",
        url: `/api/Customer/GetInsuranceById?insuranceId=${insuranceId}`,
        dataType: "json",
        success: function (data) {
            console.log('Selected Insurance:', data);
            updateDadosGerais(data);
            const pagarButton = document.getElementById('payButton');
            pagarButton.addEventListener('click', function () {
                handlePagar();
            });
        },
        error: function (xhr, status, error) {
            console.error('Error fetching insurance data:', error);
        }
    });

    function updateDadosGerais(insuranceData) {
        const dadosGeraisSection = document.getElementById('dados-gerais');
        const startDate = new Date(insuranceData.startDate);
        const endDate = new Date(insuranceData.endDate);
        dadosGeraisSection.innerHTML = `
                    <div class="container" style="background: lightgray;color:#014751;margin: 0 auto;">
                        <br />
                            <table style="margin-left:auto;margin-right:auto;">
                            <tbody>
                                <tr>
                                    <td style="text-align:right;padding-right:60px"><b>Tomador</b></td>
                                    <td style="text-align:left;">${insuranceData.insuranceHolder}</td>
                                </tr>
                                <tr>
                                    <td style="text-align:right;padding-right:60px"><b>Tipo de Ap\u00F3lice</b></td>
                                    <td style="text-align:left;">${insuranceData.type}</td>
                                </tr>
                                <tr>
                                    <td style="text-align:right;padding-right:60px"><b>Forma de Pagamento</b></td>
                                    <td style="text-align:left">${insuranceData.paymentMethod}</td>
                                </tr>
                                <tr>
                                    <td style="text-align:right;padding-right:60px"><b>Pr\u00E9mio Anual</b></td>
                                    <td style="text-align:left">${insuranceData.cost}\u20AC</td>
                                </tr>
                                <tr>
                                     <td style="text-align:right;padding-right:60px"><b>Periodicidade de Pagamento</b></td>
                                     <td style="text-align:left">${insuranceData.frequency}</td>
                                </tr>
                                <tr>
                                     <td style="text-align:right;padding-right:60px"><b>Data de In\u00EDcio</b></td>
                                             <td style="text-align:left">${startDate.toLocaleDateString("pt-PT", { day: 'numeric', month: 'long', year: 'numeric' })}</td>
                                </tr>
                                    <tr>
                                         <td style="text-align:right;padding-right:60px"><b>Data do Fim</b></td>
                                             <td style="text-align:left">${endDate.toLocaleDateString("pt-PT", { day: 'numeric', month: 'long', year: 'numeric' })}</td>
                                    </tr>
                            </tbody>
                        </table>
                        <br />
                        <div class="mb-4 d-grid">
                            <button id="payButton" type="button" class="btn btn-primary-custom">PAGAR</button>
                        </div>
                    </div>
                `;
    }

    const navbarContainer = document.getElementById('navbarContainer');
    navbarContainer.style.display = 'block';
}

function changeColorAndShowContent(element, sectionId) {
    const links = document.querySelectorAll('#myNavbar .navbar-nav .nav-link');
    links.forEach(link => {
        link.classList.remove('active');
    });

    element.classList.add('active');

    const sections = document.getElementsByClassName('content-section');
    for (let i = 0; i < sections.length; i++) {
        sections[i].style.display = 'none';
    }

    const selectedSection = document.getElementById(sectionId);
    if (selectedSection) {
        selectedSection.style.display = 'block';
    }

    window.scrollTo({
        top: selectedSection.offsetTop,
        behavior: 'smooth'
    });
}
window.addEventListener('DOMContentLoaded', () => {
    const sections = document.querySelectorAll('.content-section');
    const navLinks = document.querySelectorAll('#myNavbar .navbar-nav .nav-link');

    function activateLink(link) {
        navLinks.forEach(navLink => {
            navLink.classList.remove('active');
        });

        link.classList.add('active');
    }

    function checkSectionInView() {
        const scrollPosition = window.scrollY;

        sections.forEach(section => {
            const sectionTop = section.offsetTop;
            const sectionHeight = section.clientHeight;

            if (scrollPosition >= sectionTop - sectionHeight * 0.25 && scrollPosition < sectionTop + sectionHeight) {
                const targetLink = document.querySelector(`#myNavbar .navbar-nav .nav-link[href="#${section.id}"]`);
                activateLink(targetLink);
            }
        });
    }
    window.addEventListener('scroll', checkSectionInView);
});

function handlePagar() {
    const selectedCard = document.querySelector('.card.selected');
    if (!selectedCard) {
        console.error('No insurance selected.');
        return;
    }

    const insuranceId = parseInt(selectedCard.querySelector('span').innerText.match(/\d+/)[0]);

    $.ajax({
        type: "POST",
        url: `/api/Customer/PayInsurance?insuranceId=${insuranceId}`,
        contentType: "application/json",
        success: function (data) {
            console.log('Insurance Payment Success:', data);
            location.reload();
        },
        error: function (xhr, status, error) {
            console.error('Error while trying to pay:', error);
        }
    });
}