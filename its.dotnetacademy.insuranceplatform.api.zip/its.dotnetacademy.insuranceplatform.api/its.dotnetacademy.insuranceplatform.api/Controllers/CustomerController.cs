﻿using its.dotnetacademy.insuranceplatform.data.Models;
using Microsoft.AspNetCore.Mvc;
using its.dotnetacademy.insuranceplatform.data.Repositories;
using Microsoft.AspNetCore.Authorization;
using Microsoft.DotNet.Scaffolding.Shared.Project;

namespace its.dotnetacademy.insuranceplatform.api.Controllers
{
    /// <summary>
    /// Controller responsable for handling authenticated customer actions.
    /// </summary>
    [Route("api/[controller]/[action]")]
    [Authorize]
    [ApiController]
    public class CustomerController : Controller
    {
        private readonly CustomerRepository _customerRepository;
        private readonly ActionsRepository _actionsRepository;
        private readonly InsuranceRepository _insuranceRepository;

        /// <summary>
        /// Initializes a new instance of the CustomerController class with the necessary repositories.
        /// </summary>
        /// <param name="customerRepository">The customer repository implementation to be used.</param>
        /// <param name="actionsRepository">The actions repository implementation to be used.</param>
        /// <param name="insuranceRepository">The insurance repository implementation to be used.</param>
        public CustomerController(ICustomerRepository customerRepository, IActionsRepository actionsRepository, IInsuranceRepository insuranceRepository)
        {
            _customerRepository = (CustomerRepository)customerRepository;
            _actionsRepository = (ActionsRepository)actionsRepository;
            _insuranceRepository = (InsuranceRepository)insuranceRepository;
        }

        /// <summary>
        /// Displays the customer dashboard with information about the customer, their insurances, and actions.
        /// </summary>
        /// <param name="email">The email of the customer whose dashboard is being displayed.</param>
        /// <returns>A view containing the customer dashboard with relevant data.</returns>
        [HttpGet]
        public IActionResult Dashboard(string email)
        {
            Customer user = _customerRepository.GetCustomerByEmail(email);

            List<Insurance> listInsurances = _insuranceRepository.GetInsurancesCustomer(user.Id).ToList();

            ViewBag.Email = email;
            ViewBag.User = user;
            ViewBag.Insurances = listInsurances;
            ViewBag.Actions = _actionsRepository.GetActionsOfUser(user.Id).ToList();
            return View();
        }

        // <summary>
        /// Displays the customer profile with relevant information.
        /// </summary>
        /// <param name="email">The email of the customer whose dashboard is being displayed.</param>
        /// <returns>A view containing the customer profile with relevant data.</returns>
        [HttpGet]
        public IActionResult Profile(string email)
        {
            Customer user = _customerRepository.GetCustomerByEmail(email);
            ViewBag.Email = email;
            ViewBag.User = user;
            return View();
        }

        /// <summary>
        /// Displays the insurances associated with the customer.
        /// </summary>
        /// <param name="email">The email of the customer whose insurances are being displayed.</param>
        /// <returns>A view containing the insurances associated with the customer.</returns>
        [HttpGet]
        public IActionResult Insurances(string email)
        {
            Customer user = _customerRepository.GetCustomerByEmail(email);
            List<Insurance> listInsurances = _insuranceRepository.GetInsurancesCustomer(user.Id).ToList();
            ViewBag.Email = email;
            ViewBag.User = user;
            ViewBag.Insurances = listInsurances;
            return View();
        }

        /// <summary>
        /// A method used for the dummy purposes to act as placehodlers.
        /// </summary>
        /// <param name="email">The email of the customer.</param>
        /// <returns>A dummy view.</returns>
        [HttpGet]
        public IActionResult Dummy(string email)
        {

            Customer user = _customerRepository.GetCustomerByEmail(email);
            ViewBag.Email = email;
            ViewBag.User = user;
            return View();
        }

        /// <summary>
        /// Displays a page for simulating and creating insurances.
        /// </summary>
        /// <param name="email">The email of the customer whose simulation page is being displayed.</param>
        /// <returns>A view for simulating and adding insurances.</returns>
        [HttpGet]
        public IActionResult Simulate(string email)
        {
            Customer user = _customerRepository.GetCustomerByEmail(email);
            ViewBag.Email = email;
            ViewBag.User = user;
            return View();
        }

        /// <summary>
        /// Retrieves an insurance object by its ID.
        /// </summary>
        /// <param name="insuranceId">The ID of the insurance to retrieve.</param>
        /// <returns>A JSON response containing the insurance object.</returns>
        [HttpGet]
        public IActionResult GetInsuranceById(int insuranceId)
        {
            Insurance insurance = _insuranceRepository.GetInsuranceById(insuranceId);
            return Json(insurance);
        }

        /// <summary>
        /// Logs out the customer by deleting the "access_token" cookie and redirects to the homepage.
        /// </summary>
        /// <returns>A redirect response to the homepage.</returns>
        [HttpGet]
        public IActionResult Logout()
        {

            Response.Cookies.Delete("access_token");
            return Redirect("/");
        }

        /// <summary>
        /// Adds a new insurance to the repository and creates an associated action.
        /// </summary>
        /// <param name="model">The insurance data to be added.</param>
        /// <returns>A JSON response indicating the success of the operation.</returns>
        [HttpPost]
        public IActionResult AddInsurance([FromBody] Insurance model)
        {
            Insurance insurance = _insuranceRepository.AddInsuranceWithGeneratedID(model.Type, model.InsuranceHolder, model.PaymentMethod, model.Frequency, model.StartDate, model.EndDate, model.Cost, model.Status);
            Actions addaction = new Actions
            {
                Title = "Criação de seguro",
                Content = "Criou um seguro",
                InsuranceID = insurance.Id,
                CustomerID = insurance.InsuranceHolder,
                UpdateDate = DateTime.Now
            };
            _actionsRepository.AddAction(addaction);
            return Ok("Insurance added successfully.");
        }

        /// <summary>
        /// Initiates the payment process for a specific insurance.
        /// </summary>
        /// <param name="insuranceId">The ID of the insurance for which the payment is made.</param>
        /// <returns>A JSON response indicating the status of the payment process.</returns>
        [HttpPost]
        public IActionResult PayInsurance(int insuranceId)
        {
            Insurance insurance = _insuranceRepository.GetInsuranceById(insuranceId);
            Console.Write(insurance.Status);
            if (insurance.Status == false)
            {
                _insuranceRepository.changeStatus(insuranceId);
                Actions payaction = new Actions
                {
                    Title = "Pagamento de seguro",
                    Content = "Pagou um seguro",
                    InsuranceID = insuranceId,
                    CustomerID = insurance.InsuranceHolder,
                    UpdateDate = DateTime.Now,
                };
                _actionsRepository.AddAction(payaction);
                return Ok("Payment complete successfully.");
            }
            else
            {
                return BadRequest("Payment not required. Insurance is already active.");
            }
        }

        /// <summary>
        /// Updates the profile picture for a customer.
        /// </summary>
        /// <param name="email">The email of the customer whose picture is being updated.</param>
        /// <param name="formFile">The profile picture file to be uploaded.</param>
        /// <returns>A redirect response to the customer's dashboard upon successful update.</returns>
        [HttpPost]
        public IActionResult UpdatePicture([FromForm] string email, [FromForm] IFormFile formFile)
        {
            Customer user = _customerRepository.GetCustomerByEmail(email);

            if (user == null)
            {
                return NotFound();
            }

            if (formFile != null && formFile.Length > 0)
            {
                using (var memoryStream = new MemoryStream())
                {
                    formFile.CopyTo(memoryStream);
                    user.Picture = memoryStream.ToArray();
                }

                _customerRepository.UpdateCustomer(user);
                return RedirectToAction("Dashboard", new { email = email });
            }
            return BadRequest("No profile picture provided.");
        }


    }
}
