﻿using Microsoft.AspNetCore.Mvc;
using its.dotnetacademy.insuranceplatform.data.Repositories;
using System.Text.Json;
using its.dotnetacademy.insuranceplatform.data.Models;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace its.dotnetacademy.insuranceplatform.api.Controllers
{
    /// <summary>
    /// Controller that handles actions related to login and registry of new customers, it's methods do not require authentication
    /// </summary>
    public class HomeController : Controller
    {

        private readonly ICustomerRepository _customerRepository;

        /// <summary>
        /// Initializes a new instance of the HomeController class with the provided customer repository.
        /// </summary>
        /// <param name="customerRepository">The customer repository implementation to be used.</param>
        public HomeController(ICustomerRepository customerRepository)
        {
            _customerRepository = customerRepository;
        }

        /// <summary>
        /// Default action method for the home page, in this case, it's the same as the login page.
        /// </summary>
        /// <returns>A view for the home page.</returns>
        public IActionResult Index()
        {
            return View();
        }

        /// <summary>
        /// Generates a JSON Web Token for a given user ID.
        /// </summary>
        /// <param name="userId">The user ID for whom the token is generated.</param>
        /// <returns>The generated JWT as a string.</returns>
        private string GenerateToken(int userId)
        {
            var mySecret = "SEGREDOSUPERSECRETOEDIFICILIMODEDECIFRARNEMMESMOOSMESTRESDAPROGRAMACAOVAODESCUBRIR";
            var mySecurityKey = new SymmetricSecurityKey(Encoding.ASCII.GetBytes(mySecret));

            var myIssuer = "Academia";
            var myAudience = "https://api.insuranceplatform.com";

            var tokenHandler = new JwtSecurityTokenHandler();
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new Claim[]
                {
            new Claim(ClaimTypes.NameIdentifier, userId.ToString()),
                }),
                Expires = DateTime.UtcNow.AddDays(7),
                Issuer = myIssuer,
                Audience = myAudience,
                SigningCredentials = new SigningCredentials(mySecurityKey, SecurityAlgorithms.HmacSha256Signature)
            };

            var token = tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(token);
        }

        /// <summary>
        /// Handles the user login request and generates a JWT upon successful login.
        /// </summary>
        /// <param name="loginData">JSON data containing the username and password for login.</param>
        /// <returns>A JSON response that indicates whether the login was successful and the generated token if successful.</returns>
        [HttpPost("login", Name = "Customer")]
        public IActionResult Login([FromBody] JsonDocument loginData)
        {
            string usernameOrId = loginData.RootElement.GetProperty("username").GetString();
            string password = loginData.RootElement.GetProperty("password").GetString();

            Console.WriteLine(usernameOrId);
            Console.WriteLine(password);

            bool isLoggedIn = _customerRepository.Login(usernameOrId, password);

            Console.WriteLine(isLoggedIn);

            if (isLoggedIn)
            {
                Customer user = _customerRepository.GetCustomerByEmail(usernameOrId);
                string token = GenerateToken(user.Id);

                return new JsonResult(new { isLoggedIn = true, token = token });
            }

            return new JsonResult(new { isLoggedIn = false, error = "Invalid username or password" });
        }

        /// <summary>
        /// Handles the user registration request and adds a new customer to the repository.
        /// </summary>
        /// <param name="formData">JSON data containing the customer registration information.</param>
        /// <returns>A JSON response indicating the success or failure of the registration process.</returns>
        [HttpPost]
        public IActionResult RegisterUser([FromBody] JsonDocument formData)
        {
            if (formData == null)
            {
                return BadRequest("Invalid JSON data.");
            }


            int nif = formData.RootElement.GetProperty("NIF").GetInt32();
            string title = formData.RootElement.GetProperty("Title").GetString();
            string documentType = formData.RootElement.GetProperty("DocumentType").GetString();
            string street = formData.RootElement.GetProperty("Street").GetString();
            string neighbourhood = formData.RootElement.GetProperty("Neighbourhood").GetString();
            string city = formData.RootElement.GetProperty("City").GetString();
            string mobileNumber = formData.RootElement.GetProperty("MobileNumber").GetString();
            string email = formData.RootElement.GetProperty("Email").GetString();
            string clientType = formData.RootElement.GetProperty("ClientType").GetString();
            string name = formData.RootElement.GetProperty("Name").GetString();
            string documentNumber = formData.RootElement.GetProperty("DocumentNumber").GetString();
            string municipality = formData.RootElement.GetProperty("Municipality").GetString();
            string province = formData.RootElement.GetProperty("Province").GetString();
            string phoneNumber = formData.RootElement.GetProperty("PhoneNumber").GetString();
            string pictureBase64 = formData.RootElement.GetProperty("Picture").GetString();
            byte[] picture = null;
            if (!string.IsNullOrEmpty(pictureBase64))
            {
                picture = Convert.FromBase64String(pictureBase64);
            }
            string password = formData.RootElement.GetProperty("Password").GetString();
            DateTime birthdate = formData.RootElement.GetProperty("Birthdate").GetDateTime();



            if (ModelState.IsValid)
            {

                var newCustomer = _customerRepository.AddCustomerWithGeneratedID(nif, title, documentType, street, neighbourhood, city, mobileNumber, email, clientType, name, documentNumber, municipality, province, phoneNumber, picture, password, birthdate);

                Console.WriteLine(newCustomer);
                return new JsonResult(new { success = true, message = "User registration successful." });
            }

            return new JsonResult(new { success = false, message = "Invalid form data. Please check the values and try again." });
        }

    }
}