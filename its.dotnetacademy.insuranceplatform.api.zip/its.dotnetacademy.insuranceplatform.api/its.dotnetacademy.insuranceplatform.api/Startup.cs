﻿using its.dotnetacademy.insuranceplatform.data;
using its.dotnetacademy.insuranceplatform.data.Repositories;
using Microsoft.EntityFrameworkCore;
using its.dotnetacademy.insuranceplatform.api.Controllers;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Microsoft.AspNetCore.Mvc.Razor;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using System.Text;

namespace its.dotnetacademy.insuranceplatform.api
{
    public class Startup
    {
        public IConfiguration Configuration { get; }

        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllers();
            services.AddEndpointsApiExplorer();
            services.AddSwaggerGen();
            services.AddDataProtection();
            services.AddRazorPages();

            services.AddDbContext<AppDbContext>(options =>
                options.UseSqlServer(Configuration.GetConnectionString("DefaultConnection")));
            services.AddScoped<ICustomerRepository, CustomerRepository>();
            services.AddScoped<IActionsRepository, ActionsRepository>();
            services.AddScoped<IInsuranceRepository,InsuranceRepository>();
            services.AddScoped<CustomerController>(provider =>
            {
                var repository = provider.GetService<ICustomerRepository>();
                var actions = provider.GetService<IActionsRepository>();
                var insurances = provider.GetService<IInsuranceRepository>();
                return new CustomerController(repository,actions,insurances);
            });
            services.AddSingleton<ITempDataProvider, SessionStateTempDataProvider>();
            services.AddSession();
            services.AddHttpContextAccessor();
            services.AddMvc(options =>
            {
                options.SuppressAsyncSuffixInActionNames = false;
            });
            services.AddControllersWithViews().AddRazorOptions(options =>
            {
                options.ViewLocationFormats.Add("/Views/Dashboard/{0}" + RazorViewEngine.ViewExtension);
            });

            services.AddDbContext<AppDbContext>(options =>
                options.UseSqlServer(Configuration.GetConnectionString("DefaultConnection")));

            //
            services.AddAuthentication(x =>
            {
                x.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                x.DefaultChallengeScheme= JwtBearerDefaults.AuthenticationScheme;
                x.DefaultScheme= JwtBearerDefaults.AuthenticationScheme;
            }).AddJwtBearer(x =>
            {
                x.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidIssuer = Configuration["JwtSettings:Issuer"],
                    ValidAudience = Configuration["JwtSettings:Audience"],
                    IssuerSigningKey = new SymmetricSecurityKey
                        (Encoding.UTF8.GetBytes(Configuration["JwtSettings:Key"]!)),
                    ValidateIssuer = true,
                    ValidateAudience = true,
                    ValidateLifetime = true,
                    ValidateIssuerSigningKey = true
                };
                x.Events = new JwtBearerEvents
                {
                    OnMessageReceived = context =>
                    {
                        if (context.Request.Cookies.TryGetValue("access_token", out var token))
                        {
                            context.Token = token;
                        }
                        return Task.CompletedTask;
                    }
                };
            });

            services.AddAuthorization();
        }

        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "API V1");
            });

            app.UseRouting();

            app.UseStaticFiles();

            app.UseAuthentication();
            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllerRoute(
                    name: "customerProfile",
                    pattern: "api/Customer/Profile",
                    defaults: new { controller = "Customer", action = "Profile" }
                ).RequireAuthorization();
                endpoints.MapControllerRoute(
                    name: "customerDashboard",
                    pattern: "api/Customer/Dashboard",
                    defaults: new { controller = "Customer", action = "Dashboard" }
                ).RequireAuthorization();

                endpoints.MapControllerRoute(
                    name: "customerInsurances",
                    pattern: "api/Customer/Insurances",
                    defaults: new { controller = "Customer", action = "Insurances" }
                ).RequireAuthorization();

                endpoints.MapControllerRoute(
                    name: "customerDummy",
                    pattern: "api/Customer/Dummy",
                    defaults: new { controller = "Customer", action = "Dummy" }
                ).RequireAuthorization();

                endpoints.MapControllerRoute(
                    name: "customerSimulate",
                    pattern: "api/Customer/Simulate",
                    defaults: new { controller = "Customer", action = "Simulate" }
                ).RequireAuthorization();

                endpoints.MapControllerRoute(
                     name: "HomeRegister",
                     pattern: "api/Home/RegisterUser",
                     defaults: new { controller = "Home", action = "RegisterUser" }
                 );

                endpoints.MapFallbackToFile("/index.html");

                endpoints.MapControllers();
            });
        }
    }
}
    