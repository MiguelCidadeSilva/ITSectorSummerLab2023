﻿using its.dotnetacademy.insuranceplatform.data.Models;
using its.dotnetacademy.insuranceplatform.data.Repositories;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace its.dotnetacademy.insuranceplatform.data.test
{
    [TestClass]
    public class InsuranceRepositoryTest
    {
        ServiceProvider? serviceProvider;

        [TestInitialize]
        public void Setup()
        {
            var services = new ServiceCollection();
            // Register your services here
            services.AddScoped<IInsuranceRepository, InsuranceRepository>();
            services.AddDbContext<AppDbContext>(options =>
            {
                // Configure the database provider and connection string for testing
                options.UseSqlServer("Server=ITSDAAS-40276\\SQLEXPRESS;Database=Academia;user id = academiauser;password = 'academiapass';TrustServerCertificate=true");
            });

            serviceProvider = services.BuildServiceProvider();
        }

        [TestMethod]
        public void get_insurances()
        {
            var insuranceRepository = serviceProvider?.GetService<IInsuranceRepository>();
            var ret = insuranceRepository != null ? insuranceRepository.GetAllInsurances() : null;
            Assert.IsNotNull(ret);
            Assert.IsTrue(ret.Count() > 0);
        }

        [TestMethod]
        public void add_insurance()
        {
            var insuranceRepository = serviceProvider?.GetService<IInsuranceRepository>();
            var initialInsuranceCount = insuranceRepository.GetAllInsurances().Count();
            var newInsurance = new Insurance
            {
                Id = 11241414,
                Type = "Car",
                InsuranceHolder = 1,
                PaymentMethod = "Credit Card",
                Frequency = "Monthly",
                StartDate = DateTime.Now,
                EndDate = DateTime.Now.AddDays(30),
                Cost = 1000,
                Status = true
            };

            var addedInsurance = insuranceRepository.AddInsurance(newInsurance);

            var finalCustomerCount = insuranceRepository.GetAllInsurances().Count();
            Assert.AreEqual(initialInsuranceCount + 1, finalCustomerCount);
            Assert.AreEqual(newInsurance.Id, addedInsurance.Id);
            Assert.AreEqual(newInsurance.Type, addedInsurance.Type);
            Assert.AreEqual(newInsurance.InsuranceHolder, addedInsurance.InsuranceHolder);
            Assert.AreEqual(newInsurance.PaymentMethod, addedInsurance.PaymentMethod);
            Assert.AreEqual(newInsurance.Frequency, addedInsurance.Frequency);
            Assert.AreEqual(newInsurance.StartDate, addedInsurance.StartDate);
            Assert.AreEqual(newInsurance.EndDate, addedInsurance.EndDate);
            Assert.AreEqual(newInsurance.Cost, addedInsurance.Cost);
            Assert.AreEqual(newInsurance.Status, addedInsurance.Status);
        }

        [TestMethod]
        public void update_insurance()
        {
            var insuranceRepository = serviceProvider?.GetService<IInsuranceRepository>();
            var initialInsuranceCount = insuranceRepository.GetAllInsurances().Count();
            var id = 11241414;
            var oldInsurance = insuranceRepository.GetInsuranceById(id);
            var newtype = "NewTestName";
            var oldtype = oldInsurance.Type;
            Assert.AreNotEqual(newtype, oldtype);
            oldInsurance.Type = newtype;
            insuranceRepository.UpdateInsurance(oldInsurance);
            var newInsurance = insuranceRepository.GetInsuranceById(id);
            Assert.AreEqual(newtype, newInsurance.Type);

            var finalCustomerCount = insuranceRepository.GetAllInsurances().Count();
            Assert.AreEqual(initialInsuranceCount, finalCustomerCount);
        }

        [TestMethod]
        public void delete_insurance()
        {
            var insuranceRepository = serviceProvider?.GetService<IInsuranceRepository>();
            var initialInsuranceCount = insuranceRepository.GetAllInsurances().Count();
            var ToDelete = 11241414;
            insuranceRepository.DeleteInsurance(ToDelete);
            var finalInsuranceCount = insuranceRepository.GetAllInsurances().Count();
            Assert.AreEqual(initialInsuranceCount, finalInsuranceCount + 1);
        }

        [TestMethod]
        public void get_insurance()
        {
            var insuranceRepository = serviceProvider?.GetService<IInsuranceRepository>();
            var ToGet = 1;
            Insurance insurance = insuranceRepository.GetInsuranceById(ToGet);
            Assert.IsNotNull(insurance);
        }

        [TestMethod]
        public void get_CustomerInsurances()
        {
            var insuranceRepository = serviceProvider?.GetService<IInsuranceRepository>();
            var ToGet = 1;
            List<Insurance> insurances = (List<Insurance>)insuranceRepository.GetInsurancesCustomer(ToGet);
            Assert.IsNotNull(insurances);
        }
    }
}
