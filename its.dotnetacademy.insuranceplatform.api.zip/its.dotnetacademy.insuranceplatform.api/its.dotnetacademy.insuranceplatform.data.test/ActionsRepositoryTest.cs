﻿
using its.dotnetacademy.insuranceplatform.data.Models;
using its.dotnetacademy.insuranceplatform.data.Repositories;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace its.dotnetacademy.insuranceplatform.data.test
{
    [TestClass]
    public class ActionsRepositoryTest
    {
        ServiceProvider? serviceProvider;

        [TestInitialize]
        public void Setup()
        {
            var services = new ServiceCollection();
            services.AddScoped<IActionsRepository, ActionsRepository>();
            services.AddDbContext<AppDbContext>(options =>
            {
                options.UseSqlServer("Server=ITSDAAS-40276\\SQLEXPRESS;Database=Academia;user id = academiauser;password = 'academiapass';TrustServerCertificate=true");
            });

            serviceProvider = services.BuildServiceProvider();
        }

        [TestMethod]
        public void get_ActionsTest()
        {
            var actionsRepository = serviceProvider?.GetService<IActionsRepository>();
            var ret = actionsRepository != null ? actionsRepository.GetAllActions() : null;
            Assert.IsNotNull(ret);
            Assert.IsTrue(ret.Count() > 0);
        }

        [TestMethod]
        public void add_ActionTest()
        {
            var actionsRepository = serviceProvider?.GetService<IActionsRepository>();
            var initialActionsCount = actionsRepository.GetAllActions().Count();
            var newAction = new Actions
            {
                CustomerID = 5,
                InsuranceID = 5,
                UpdateDate = new DateTime(2023, 07, 15, 12, 34, 56),
                Title="Test",
                Content = "Test"
               
            };

            var addedAction = actionsRepository.AddAction(newAction);

            var finalActionsCount = actionsRepository.GetAllActions().Count();
            Assert.AreEqual(initialActionsCount + 1, finalActionsCount);
            Assert.AreEqual(newAction.CustomerID, addedAction.CustomerID);
            Assert.AreEqual(newAction.InsuranceID, addedAction.InsuranceID);
        }

        [TestMethod]
        public void delete_ActionsTest()
        {
            var actionsRepository = serviceProvider?.GetService<IActionsRepository>();
            var initialActionsCount = actionsRepository.GetAllActions().Count();
            var ToDelete=(5,5,new DateTime(2023, 07, 15, 12, 34, 56));
            actionsRepository.DeleteAction(ToDelete.Item1,ToDelete.Item2,ToDelete.Item3);
            var finalActionsCount = actionsRepository.GetAllActions().Count();
            Assert.AreEqual(initialActionsCount, finalActionsCount+1);
        }

        [TestMethod]
        public void get_ActionsCustomerTest()
        {
            var actionsRepository = serviceProvider?.GetService<IActionsRepository>();
            var ToGet = 1;
            IEnumerable<Actions> actions = actionsRepository.GetActionsOfUser(ToGet);
            Assert.IsNotNull(actions);
        }

        [TestMethod]
        public void update_ActionTest()
        {
            var actionsRepository = serviceProvider?.GetService<IActionsRepository>();
            var initialActionsCount = actionsRepository.GetAllActions().Count();
            var oldValues = new Actions //added in previous test
            {
                CustomerID = 5,
                InsuranceID = 5,
                UpdateDate = new DateTime(2023, 07, 15, 12, 34, 56),
                Title="Test",
                Content = "Test"
            };
            var newValues = new Actions
            {
                CustomerID = 5,
                InsuranceID = 5,
                UpdateDate = new DateTime(2023, 07, 15, 12, 34, 56),
                Title="Test",
                Content = "CHANGED"
            };

            Assert.AreNotEqual(oldValues, newValues);
            actionsRepository.UpdateAction(oldValues, newValues);
            var finalActionsCount = actionsRepository.GetAllActions().Count();
            Assert.AreEqual(initialActionsCount, finalActionsCount);
        }
    }
}
