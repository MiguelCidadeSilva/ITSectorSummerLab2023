﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Extensions.DependencyInjection;
using its.dotnetacademy.insuranceplatform.data.Repositories;
using Microsoft.EntityFrameworkCore;
using its.dotnetacademy.insuranceplatform.data.Models;

namespace its.dotnetacademy.insuranceplatform.data.test
{
    [TestClass]
    public class CustomerRepositoryTest
    {
        ServiceProvider? serviceProvider;

        [TestInitialize]
        public void Setup()
        {
            var services = new ServiceCollection();
            services.AddScoped<ICustomerRepository, CustomerRepository>();
            services.AddDbContext<AppDbContext>(options =>
            {
                options.UseSqlServer("Server=ITSDAAS-40276\\SQLEXPRESS;Database=Academia;user id = academiauser;password = 'academiapass';TrustServerCertificate=true");
            });

            serviceProvider = services.BuildServiceProvider();
        }

        [TestMethod]
        public void get_customers()
        {
            var customerRepository = serviceProvider?.GetService<ICustomerRepository>();
            var ret = customerRepository != null ? customerRepository.GetAllCustomers() : null;
            Assert.IsNotNull(ret);
            Assert.IsTrue(ret.Count()>0);
        }


        [TestMethod]
        public void add_customer()
        {
            var customerRepository = serviceProvider?.GetService<ICustomerRepository>();
            var initialCustomerCount = customerRepository.GetAllCustomers().Count();
            var newCustomer = new Customer
            {
                Id = 13145,
                NIF = 123456789,
                Title = "Mr",
                DocumentType = "Passport",
                Street = "123 Main St",
                Neighbourhood = "Central",
                City = "Cityville",
                MobileNumber = "+123456789",
                Email = "test@example.com",
                ClientType = "Regular",
                Name = "Test Man",
                DocumentNumber = "ABC123",
                Municipality = "City A",
                Province = "Province X",
                PhoneNumber = "+987654321",
                Picture = null,
                Password = "password1",
                Birthdate = new DateTime(1990, 1, 1)
            };

            var addedCustomer = customerRepository.AddCustomer(newCustomer);

            var finalCustomerCount = customerRepository.GetAllCustomers().Count();
            Assert.AreEqual(initialCustomerCount + 1, finalCustomerCount);
            Assert.AreEqual(newCustomer.Id, addedCustomer.Id);
            Assert.AreEqual(newCustomer.NIF, addedCustomer.NIF);
            Assert.AreEqual(newCustomer.Title, addedCustomer.Title);
            Assert.AreEqual(newCustomer.DocumentType, addedCustomer.DocumentType);
            Assert.AreEqual(newCustomer.Street, addedCustomer.Street);
            Assert.AreEqual(newCustomer.Neighbourhood, addedCustomer.Neighbourhood);
            Assert.AreEqual(newCustomer.City, addedCustomer.City);
            Assert.AreEqual(newCustomer.MobileNumber, addedCustomer.MobileNumber);
            Assert.AreEqual(newCustomer.Email, addedCustomer.Email);
            Assert.AreEqual(newCustomer.ClientType, addedCustomer.ClientType);
            Assert.AreEqual(newCustomer.Name, addedCustomer.Name);
            Assert.AreEqual(newCustomer.DocumentNumber, addedCustomer.DocumentNumber);
            Assert.AreEqual(newCustomer.Municipality, addedCustomer.Municipality);
            Assert.AreEqual(newCustomer.Province, addedCustomer.Province);
            Assert.AreEqual(newCustomer.PhoneNumber, addedCustomer.PhoneNumber);
            Assert.AreEqual(newCustomer.Picture, addedCustomer.Picture);
            Assert.AreEqual(newCustomer.Password, addedCustomer.Password);
            Assert.AreEqual(newCustomer.Birthdate, addedCustomer.Birthdate);
        }


        [TestMethod]
        public void login_test()
        {
            var customerRepository = serviceProvider?.GetService<ICustomerRepository>();
            var username = "customer1@example.com";
            var password = "password1";
            var username2 = "asfafuajijfejoqihrqujfdhsdjf";
            var password2 = "ajfsfjaiosfjaisfjsoiajgijaikaosik";
            var login1 = customerRepository.Login(username,password);
            var login2 = customerRepository.Login(username2, password2);
            Assert.IsTrue(login1);
            Assert.IsFalse(login2);
        }

        [TestMethod]
        public void update_customer() {
            var customerRepository = serviceProvider?.GetService<ICustomerRepository>();
            var initialCustomerCount = customerRepository.GetAllCustomers().Count();
            var id = 13145;
            var oldCustomer = customerRepository.GetCustomerById(id);
            var newname = "NewTestName";
            var oldname = oldCustomer.Name;
            Assert.AreNotEqual(newname,oldname);
            oldCustomer.Name=newname;
            customerRepository.UpdateCustomer(oldCustomer);
            var newCustomer = customerRepository.GetCustomerById(id);
            Assert.AreEqual(newname, newCustomer.Name);

            var finalCustomerCount = customerRepository.GetAllCustomers().Count();
            Assert.AreEqual(initialCustomerCount, finalCustomerCount);
        }


        [TestMethod]
        public void delete_customer()
        {
            var customerRepository = serviceProvider?.GetService<ICustomerRepository>();
            var initialCustomerCount = customerRepository.GetAllCustomers().Count();
            var ToDelete = 13145;
            customerRepository.DeleteCustomer(ToDelete);
            var finalCustomerCount = customerRepository.GetAllCustomers().Count();
            Assert.AreEqual(initialCustomerCount, finalCustomerCount + 1);
        }


        [TestMethod]
        public void get_customer()
        {
            var customerRepository = serviceProvider?.GetService<ICustomerRepository>();
            var ToGet = 1;
            Customer customer = customerRepository.GetCustomerById(ToGet);
            Assert.IsNotNull(customer);
        }

    }
}

