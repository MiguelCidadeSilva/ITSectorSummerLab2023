﻿namespace its.dotnetacademy.insuranceplatform.data.Models
{
    /// <summary>
    /// Represents a Customer, which can be seen as a user profile in the application.
    /// </summary>
    public class Customer
    {
        /// <summary>
        /// Gets or sets the unique identifier of the user profile.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets NIF user.
        /// </summary>
        public int NIF { get; set; }

        public string? Title { get; set; }
        /// <summary>
        /// Gets or sets the type of document that identifies the user.
        /// </summary>
        public string? DocumentType { get; set; }

        /// <summary>
        /// Gets or sets the user's street.
        /// </summary>
        public string? Street { get; set; }

        /// <summary>
        /// Gets or sets the neighbourhood of the user.
        /// </summary>
        public string? Neighbourhood { get; set; }

        /// <summary>
        /// Gets or sets the city of the user.
        /// </summary>
        public string? City { get; set; }

        /// <summary>
        /// Gets or sets the mobile number of the user.
        /// </summary>
        public string? MobileNumber { get; set; }

        /// <summary>
        /// Gets or sets the email address of the user.
        /// </summary>
        public string Email { get; set; }

        /// <summary>
        /// Gets or sets the client type of a user.
        /// </summary>
        public string? ClientType { get; set; }

        /// <summary>
        /// Gets or sets the full name of the user.
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets the number of the document that identifies the user.
        /// </summary>
        public string ?DocumentNumber { get; set; }

        /// <summary>
        /// Gets or sets the municipality of the user.
        /// </summary>
        public string ?Municipality { get; set; }

        /// <summary>
        /// Gets or sets the province of the user.
        /// </summary>
        public string ?Province { get; set; }

        /// <summary>
        /// Gets or sets the phone number of the user.
        /// </summary>
        public string ?PhoneNumber { get; set; }

        /// <summary>
        /// Gets or sets the picture of the user.
        /// </summary>
        public byte[]? Picture { get; set; }

        /// <summary>
        /// Gets or sets the password of the user.
        /// </summary>
        public string Password { get; set; }

        /// <summary>
        /// Gets or sets the date of birth of the user.
        /// </summary>
        public DateTime Birthdate { get; set; }
    }
}
