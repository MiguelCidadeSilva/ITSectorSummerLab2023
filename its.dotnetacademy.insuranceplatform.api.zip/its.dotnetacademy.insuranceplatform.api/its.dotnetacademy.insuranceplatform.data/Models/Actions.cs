﻿namespace its.dotnetacademy.insuranceplatform.data.Models
{
    /// <summary>
    /// Represents actions done in the application.
    /// </summary>
    public class Actions
    {
        /// <summary>
        /// Gets or sets the CustomerID of the customer who performed the action.
        /// </summary>
        public int CustomerID { get; set; }

        /// <summary>
        /// Gets or sets the InsuranceID of the insurance upon which the action was performed.
        /// </summary>
        public int InsuranceID { get; set; }

        /// <summary>
        /// Gets or sets the UpdateDate of an action.
        /// </summary>
        public DateTime UpdateDate {get; set; }

        /// <summary>
        /// Gets or sets the Title of an action.
        /// </summary>
        public string Title { get; set; }

        /// <summary>
        /// Gets or sets the Content of an action
        /// </summary>
        public string Content { get; set; }
    }
}
