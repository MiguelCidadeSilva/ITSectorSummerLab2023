﻿namespace its.dotnetacademy.insuranceplatform.data.Models
{
    /// <summary>
    /// Represents an insurance in the application.
    /// </summary>
    public class Insurance
    {
        /// <summary>
        /// Gets or sets the unique identifier of the insurance.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the type of the insurance.
        /// </summary>
        public string Type { get; set; }

        /// <summary>
        /// Gets or sets the identifier of the insurance holder.
        /// </summary>
        public int InsuranceHolder { get; set; }

        /// <summary>
        /// Gets or sets the payment method for the insurance.
        /// </summary>
        public string PaymentMethod { get; set; }

        /// <summary>
        /// Gets or sets the frequency of premium payments.
        /// </summary>
        public string Frequency { get; set; }

        /// <summary>
        /// Gets or sets the start date of the insurance coverage.
        /// </summary>
        public DateTime StartDate { get; set; }

        /// <summary>
        /// Gets or sets the end date of the insurance coverage.
        /// </summary>
        public DateTime EndDate { get; set; }

        /// <summary>
        /// Gets or sets the cost of the insurance.
        /// </summary>
        public Decimal Cost { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether the insurance is paid or not.
        /// </summary>
        public bool Status { get; set; }
    }
}
