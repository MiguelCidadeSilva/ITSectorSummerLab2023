﻿using its.dotnetacademy.insuranceplatform.data.Models;

namespace its.dotnetacademy.insuranceplatform.data.Repositories
{
    /// <summary>
    /// Interface containing methods needed to implement a repository of structures that represent a registry actions performed in the platform, such as updating, creating and paying insurances.
    /// </summary>
    public interface IActionsRepository
    {
        /// <summary>
        /// Gets all the Actions class objects of the repository in an IEnumerable.
        /// </summary>
        /// <returns>IEnumerable with all the Actions.</returns>
        public IEnumerable<Actions> GetAllActions();

        /// <summary>
        /// Gets all the Actions of a Customer in the repository in an IEnumerable.
        /// </summary>
        /// <param name="customerId">The ID of the Customer whose actions</param>
        /// <returns>IEnumerable with all the Actions.</returns>
        public IEnumerable<Actions> GetActionsOfUser(int customerId);

        /// <summary>
        /// Adds an Actions class object to the repository of Actions.
        /// </summary>
        /// <param name="action">The action to add to the repository.</param>
        /// <returns>The added Actions class object.</returns>
        public Actions AddAction(Actions action);

        /// <summary>
        /// Updates an Action class object on the repository of Actions.
        /// </summary>
        /// <param name="oldAction">The Actions class object to add to update on the repository.</param>
        /// <param name="newAction">The values that will replace the original values on the repository in te form of an Actions class.</param>
        /// <returns>Actions structure with the updated information.</returns>
        public Actions UpdateAction(Actions oldAction, Actions newAction);
        
        /// <summary>
        /// Deletes an Actions class object from the Actions repository.
        /// </summary>
        /// <param name="customerId"></param>
        /// <param name="insuranceId"></param>
        /// <param name="updateTime"></param>
        public void DeleteAction(int customerId,int insuranceId,DateTime updateTime);
    }
}
