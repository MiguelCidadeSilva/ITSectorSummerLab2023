﻿using its.dotnetacademy.insuranceplatform.data.Models;

namespace its.dotnetacademy.insuranceplatform.data.Repositories
{
    /// <summary>
    /// Interface containing methods needed to implement a repository of structures that represent an Insurance.
    /// </summary>
    public interface IInsuranceRepository
    {
        /// <summary>
        /// Gets all the Insurances of the repository in an IEnumerable.
        /// </summary>
        /// <returns>IEnumerable with all the Insurances.</returns>
        public IEnumerable<Insurance> GetAllInsurances();

        /// <summary>
        /// Retrieves an Insurance on the repository based on it's ID.
        /// </summary>
        /// <param name="insuranceId">The ID of the insurance.</param>
        /// <returns>The Insurance identified by the given ID.</returns>
        public Insurance GetInsuranceById(int insuranceId);

        /// <summary>
        /// Adds an Insurance to the repository.
        /// </summary>
        /// <param name="insurance">The insurance to add.</param>
        /// <returns>The Insurance added insurance.</returns>
        public Insurance AddInsurance(Insurance insurance);

        /// <summary>
        /// Updates an insurance of the repository, giving it new values.
        /// </summary>
        /// <param name="insurance">The insurance to update.</param>
        /// <returns>The updated insurance.</returns>
        public Insurance UpdateInsurance(Insurance insurance);

        /// <summary>
        /// Deletes an Insurance on the repository based on it's ID.
        /// </summary>
        /// <param name="insuranceId">The ID of the insurance to delete.</param>
        public void DeleteInsurance(int insuranceId);

        /// <summary>
        /// Retrieves all Insurances of a customer on the platform.
        /// </summary>
        /// <param name="customerId">The ID of the customer whose <insurances will be retrieved.</param>
        /// <returns>IEnumerable with all insurances of a customer.</returns>
        public IEnumerable<Insurance> GetInsurancesCustomer(int customerId);

        /// <summary>
        /// Adds an insurance to the repository, generating it's ID.
        /// </summary>
        /// <param name="type">The type of the insurance.</param>
        /// <param name="holder">The holder of the insurance.</param>
        /// <param name="paymentmethod">The payment method used for the insurance.</param>
        /// <param name="frequency">The frequency of payment for the insurance.</param>
        /// <param name="startDate">The start date of the insurance.</param>
        /// <param name="endDate">The end date of the insurance.</param>
        /// <param name="cost">The cost of the insurance.</param>
        /// <param name="status">The status of the insurance.</param>
        /// <returns>The Insurance identified by the given ID.</returns>
        public Insurance AddInsuranceWithGeneratedID(string type, int holder, string paymentmethod, string frequency, DateTime startDate, DateTime endDate, Decimal cost, bool status);

        /// <summary>
        /// Changes the status of an insurance.
        /// </summary>
        /// <param name="insuranceId">The ID of the insurance whose status will be changed.</param>
        /// <returns>The Insurance with it's new status.</returns>
        public Insurance changeStatus(int insuranceId);

    }
}
