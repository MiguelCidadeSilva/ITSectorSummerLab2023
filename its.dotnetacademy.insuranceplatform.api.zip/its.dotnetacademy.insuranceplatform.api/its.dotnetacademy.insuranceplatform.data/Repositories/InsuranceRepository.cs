﻿using its.dotnetacademy.insuranceplatform.data.Models;

namespace its.dotnetacademy.insuranceplatform.data.Repositories
{
    public class InsuranceRepository : IInsuranceRepository
    {
        private readonly AppDbContext _appDbContext;

        public InsuranceRepository(AppDbContext context)
        {
            this._appDbContext = context;
        }
        public Insurance AddInsurance(Insurance insurance)
        {
            var addedInsurance = _appDbContext.Insurances.Add(insurance);
            _appDbContext.SaveChanges();
            return addedInsurance.Entity;
        }

        public void DeleteInsurance(int insuranceId)
        {
            var foundInsurance = _appDbContext.Insurances.FirstOrDefault(e => e.Id == insuranceId);
            if (foundInsurance == null) return;
            _appDbContext.Insurances.Remove(foundInsurance);
            _appDbContext.SaveChanges();
        }

        public IEnumerable<Insurance> GetAllInsurances()
        {
            return _appDbContext.Insurances;
        }

        public Insurance GetInsuranceById(int insuranceId)
        {
            return _appDbContext.Insurances.FirstOrDefault(m => m.Id == insuranceId);
        }

        public IEnumerable<Insurance> GetInsurancesCustomer(int customerId)
        {
            return _appDbContext.Insurances
                .Where(e => e.InsuranceHolder == customerId).ToList();
        }

        public Insurance AddInsuranceWithGeneratedID(string type, int holder, string paymentmethod, string frequency, DateTime startDate, DateTime endDate, Decimal cost, bool status)
        {
            int maxId = _appDbContext.Insurances.Any() ? _appDbContext.Insurances.Max(i => i.Id) : 0;
            Insurance insurance = new Insurance
            {
                Id = maxId + 1,
                Type = type,
                InsuranceHolder = holder,
                PaymentMethod = paymentmethod,
                Frequency = frequency,
                StartDate = startDate,
                EndDate = endDate,
                Cost = cost,
                Status = status
            };


            _appDbContext.Insurances.Add(insurance);
            _appDbContext.SaveChanges();
            return insurance;
        }

        public Insurance changeStatus(int insuranceId)
        {
            var foundInsurance = _appDbContext.Insurances.FirstOrDefault(e => e.Id == insuranceId);
            foundInsurance.Status = !foundInsurance.Status;
            _appDbContext.SaveChanges();
            return foundInsurance;
        }

        public Insurance UpdateInsurance(Insurance insurance)
        {
            var foundInsurance = _appDbContext.Insurances.FirstOrDefault(e => e.Id == insurance.Id);
            foundInsurance.Type = insurance.Type;
            foundInsurance.InsuranceHolder = insurance.InsuranceHolder;
            foundInsurance.PaymentMethod = insurance.PaymentMethod;
            foundInsurance.Frequency = insurance.Frequency;
            foundInsurance.StartDate = insurance.StartDate;
            foundInsurance.EndDate = insurance.EndDate;
            foundInsurance.Cost = insurance.Cost;
            _appDbContext.SaveChanges();
            return foundInsurance;
        }
    }
}
