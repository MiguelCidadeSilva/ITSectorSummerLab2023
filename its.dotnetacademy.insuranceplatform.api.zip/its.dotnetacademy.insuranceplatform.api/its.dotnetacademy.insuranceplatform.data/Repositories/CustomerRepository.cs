﻿using its.dotnetacademy.insuranceplatform.data.Models;

namespace its.dotnetacademy.insuranceplatform.data.Repositories
{
    public class CustomerRepository : ICustomerRepository
    {
        private readonly AppDbContext _appDbContext;

        public CustomerRepository(AppDbContext context)
        {
            this._appDbContext = context;
        }

        public Customer AddCustomer(Customer customer)
        {
            var addedCustomer = _appDbContext.Customers.Add(customer);
            _appDbContext.SaveChanges();
            return addedCustomer.Entity;
        }

        public void DeleteCustomer(int customerId)
        {
            var foundCustomer = _appDbContext.Customers.FirstOrDefault(e => e.Id == customerId);
            if (foundCustomer == null) return;
            _appDbContext.Customers.Remove(foundCustomer);
            _appDbContext.SaveChanges();
        }

        public IEnumerable<Customer> GetAllCustomers()
        {
            return _appDbContext.Customers;
        }

        public Customer GetCustomerById(int customerId)
        {
            return _appDbContext.Customers.FirstOrDefault(m=>m.Id== customerId);
        }

        public Customer UpdateCustomer(Customer customer)
        {
            var foundCustomer = _appDbContext.Customers.FirstOrDefault(e => e.Id == customer.Id);
            foundCustomer.Id = customer.Id;
            foundCustomer.NIF =customer.NIF;
            foundCustomer.DocumentType= customer.DocumentType;
            foundCustomer.Street= customer.Street;
            foundCustomer.Neighbourhood = foundCustomer.Neighbourhood;
            foundCustomer.City = customer.City;
            foundCustomer.MobileNumber = customer.MobileNumber;
            foundCustomer.Email = customer.Email;
            foundCustomer.ClientType = customer.ClientType;
            foundCustomer.Name = customer.Name;
            foundCustomer.DocumentNumber = customer.DocumentNumber;
            foundCustomer.Municipality = customer.Municipality;
            foundCustomer.Province = customer.Province;
            foundCustomer.PhoneNumber = customer.PhoneNumber;
            foundCustomer.Picture = customer.Picture;
            foundCustomer.Password=customer.Password;
            foundCustomer.Birthdate = customer.Birthdate;
            _appDbContext.SaveChanges();
            return foundCustomer;
        }


        public Customer AddCustomerWithGeneratedID(int nif,string title, string documenttype, string street, string neighbourhood, string city, string mobilenumber, string email, string clientype, string name, string documentnumber, string municipality, string province, string phonenumber, byte[] picture,string password, DateTime birthdate)
        {
            int maxId = _appDbContext.Customers.Any() ? _appDbContext.Customers.Max(i => i.Id) : 0;
            Customer customer = new Customer
            {
                Id = maxId + 1,
                NIF = nif,
                DocumentType = documenttype,
                Street = street,
                Neighbourhood = neighbourhood,
                City = city,
                MobileNumber = mobilenumber,
                Email = email,
                ClientType = clientype,
                Name = name,
                DocumentNumber = documentnumber,
                Municipality = municipality,
                Province = province,
                PhoneNumber = phonenumber,
                Picture = picture,
                Password = password,
                Birthdate = birthdate
            };
            _appDbContext.Customers.Add(customer);
            _appDbContext.SaveChanges();
            return customer;
        }

        public Customer GetCustomerByEmail(string email)
        {
            return _appDbContext.Customers.FirstOrDefault(m => m.Email == email);
        }


        public bool Login(string email, string password)
        {
            
            var foundCustomer = _appDbContext.Customers.FirstOrDefault(e => e.Email == email && e.Password == password);
            return foundCustomer != null;
        }

        
    }
}
