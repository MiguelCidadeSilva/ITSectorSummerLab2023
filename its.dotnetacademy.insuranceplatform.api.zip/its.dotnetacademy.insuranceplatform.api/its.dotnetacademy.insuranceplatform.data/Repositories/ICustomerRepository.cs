﻿using its.dotnetacademy.insuranceplatform.data.Models;

namespace its.dotnetacademy.insuranceplatform.data.Repositories
{
    /// <summary>
    /// Interface containing methods needed to implement a repository of structures that represent a customer.
    /// </summary>
    public interface ICustomerRepository

    {
        /// <summary>
        /// Gets all the Customers of the repository in an IEnumerable.
        /// </summary>
        /// <returns>IEnumerable with all the Customers.</returns>
        public IEnumerable<Customer> GetAllCustomers();

        /// <summary>
        /// Retrieves a Customer on the repository based on ID.
        /// </summary>
        /// <param name="customerById">The ID of the Customer.</param>
        /// <returns>The Customer identified by the given ID.</returns>
        public Customer GetCustomerById(int customerById);
        
        /// <summary>
        /// Retrieves a Customer on the repository based on their email.
        /// </summary>
        /// <param name="email">The email of the Customer.</param>
        /// <returns>The Customer identified by the given email.</returns>
        public Customer GetCustomerByEmail(string email);

        /// <summary>
        /// Adds a Customer to the repository.
        /// </summary>
        /// <param name="customer">The Customer to add to the repository.</param>
        /// <returns>The added Customer.</returns>
        public Customer AddCustomer(Customer customer);

        /// <summary>
        /// Adds a Customer to the repository, generating it's ID.
        /// </summary>
        /// <param name="nif">The NIF of the Customer.</param>
        /// <param name="title">The title of the Customer.</param>
        /// <param name="documenttype">The type of document used by the Customer.</param>
        /// <param name="street">The street of whre the Customer resides.</param>
        /// <param name="neighbourhood">The neighbourhood of the Customer.</param>
        /// <param name="city">The city of whre the Customer lives.</param>
        /// <param name="mobilenumber">The Customer's mobile number.</param>
        /// <param name="email">The email of the Customer.</param>
        /// <param name="clientype">The type of the Customer.</param>
        /// <param name="name">The full name of the Customer.</param>
        /// <param name="documentnumber">The Customer's document number.</param>
        /// <param name="municipality">The municipality where the Customer lives.</param>
        /// <param name="province">The province of the Customer.</param>
        /// <param name="phonenumber">The Customer's phone number.</param>
        /// <param name="picture">The Customer's picture.</param>
        /// <param name="password">The Customer's password.</param>
        /// <param name="birthdate">The Customer's birthdate.</param>
        /// <returns>The added Customer</returns>
        public Customer AddCustomerWithGeneratedID(int nif, string title, string documenttype, string street, string neighbourhood, string city, string mobilenumber, string email, string clientype, string name, string documentnumber, string municipality, string province, string phonenumber, byte[] picture, string password, DateTime birthdate);

        /// <summary>
        /// Adds a Customer to the repository.
        /// </summary>
        /// <param name="customer">The Customer to add of to the repository.</param>
        /// <returns>The added Customer</returns>
        public Customer UpdateCustomer(Customer customer);

        /// <summary>
        /// Deletes a Customer to the repository.
        /// </summary>
        /// <param name="customerId">The id of Customer to delete from the repository.</param>
        /// <returns>The added Customer</returns>
        void DeleteCustomer(int customerId);

        /// <summary>
        /// Method for login in a Customer.
        /// </summary>
        /// <param name="email">The custome's email.</param>
        /// <param name="password">The custome's password.</param>
        /// <returns>A boolean that returs true of the Customer is in authenticated correctly, false otherwise</returns>
        public bool Login(string email, string password);

    }
}
