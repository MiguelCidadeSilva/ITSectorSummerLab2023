﻿using its.dotnetacademy.insuranceplatform.data.Models;
using System;

namespace its.dotnetacademy.insuranceplatform.data.Repositories
{
    public class ActionsRepository : IActionsRepository
    {
        private readonly AppDbContext _appDbContext;

        public ActionsRepository(AppDbContext appDbContext)
        {
            this._appDbContext = appDbContext;
        }

        public Actions AddAction(Actions action)
        {
            var addedAction = _appDbContext.Actions.Add(action);
            _appDbContext.SaveChanges();
            return addedAction.Entity;
        }

        public void DeleteAction(int customerId, int insuranceId, DateTime updateTime)
        {
            var foundAction = _appDbContext.Actions.FirstOrDefault(e => e.CustomerID == customerId && e.InsuranceID == insuranceId && e.UpdateDate == updateTime);
            if (foundAction == null) return;
            _appDbContext.Actions.Remove(foundAction);
            _appDbContext.SaveChanges();
        }

        public IEnumerable<Actions> GetActionsOfUser(int customerId)
        {
            return _appDbContext.Actions
                .Where(e => e.CustomerID==customerId).ToList();
        }

        public IEnumerable<Actions> GetAllActions()
        {
            return _appDbContext.Actions;
        }

        public Actions UpdateAction(Actions oldAction, Actions newAction)
        {
            var foundAction = _appDbContext.Actions.FirstOrDefault(e => e.CustomerID == oldAction.CustomerID && e.InsuranceID == oldAction.InsuranceID && e.UpdateDate == oldAction.UpdateDate);
            if (foundAction == null)
            {
                throw new InvalidOperationException("Entity with the specified composite key not found.");
            }
            _appDbContext.Actions.Remove(foundAction);
            var updatedAction = new Actions
            {
                CustomerID = newAction.CustomerID,
                InsuranceID = newAction.InsuranceID,
                UpdateDate = newAction.UpdateDate,
                Title = newAction.Title,
                Content = newAction.Content
            };
            _appDbContext.Actions.Add(updatedAction);
            _appDbContext.SaveChanges();
            return updatedAction;
        }
    }
}
