﻿using Microsoft.EntityFrameworkCore;
using its.dotnetacademy.insuranceplatform.data.Models;
namespace its.dotnetacademy.insuranceplatform.data
{
    public class AppDbContext : DbContext 
    {
  
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
        }
        public DbSet<Customer> Customers {  get; set; }
        
        public DbSet<Insurance> Insurances { get; set; }

        public DbSet<Actions> Actions { get; set; } 

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Actions>().HasKey(a => new { a.CustomerID, a.InsuranceID, a.UpdateDate });
            base.OnModelCreating(modelBuilder);
        }
    }
}
